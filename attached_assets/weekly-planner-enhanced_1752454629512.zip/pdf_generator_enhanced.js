const puppeteer = require('puppeteer');
const fs = require('fs').promises;
const path = require('path');
const Handlebars = require('handlebars');

class WeeklyPlannerPDFGenerator {
    constructor() {
        this.browser = null;
        this.weeklyTemplate = null;
        this.dailyTemplate = null;
        
        // Register Handlebars helpers
        Handlebars.registerHelper('isArray', function(value) {
            return Array.isArray(value);
        });
    }

    async initialize() {
        // Load and compile templates
        const weeklyHtml = await fs.readFile(path.join(__dirname, 'weekly_template.html'), 'utf8');
        const dailyHtml = await fs.readFile(path.join(__dirname, 'daily_template_enhanced.html'), 'utf8');
        
        this.weeklyTemplate = Handlebars.compile(weeklyHtml);
        this.dailyTemplate = Handlebars.compile(dailyHtml);
        
        // Launch browser
        this.browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
    }

    async generatePDF(weekData, outputPath) {
        if (!this.browser) {
            await this.initialize();
        }

        const pages = [];
        
        // Generate weekly overview page
        const weeklyPage = await this.generateWeeklyPage(weekData);
        pages.push(weeklyPage);
        
        // Generate daily pages
        const dayNames = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        for (const dayName of dayNames) {
            const dailyPage = await this.generateDailyPage(weekData, dayName);
            pages.push(dailyPage);
        }
        
        // Combine all pages into single PDF
        await this.combinePagesIntoPDF(pages, outputPath);
        
        return outputPath;
    }

    async generateWeeklyPage(weekData) {
        const page = await this.browser.newPage();
        
        // Process data for weekly template
        const processedData = this.processWeeklyData(weekData);
        
        // Render HTML
        const html = this.weeklyTemplate(processedData);
        
        await page.setContent(html, { waitUntil: 'networkidle0' });
        
        // Generate PDF buffer
        const pdfBuffer = await page.pdf({
            format: 'Letter',
            landscape: true,
            margin: {
                top: '0.25in',
                right: '0.25in',
                bottom: '0.25in',
                left: '0.25in'
            },
            printBackground: true,
            preferCSSPageSize: true
        });
        
        await page.close();
        return pdfBuffer;
    }

    async generateDailyPage(weekData, dayName) {
        const page = await this.browser.newPage();
        
        // Process data for daily template
        const processedData = this.processDailyData(weekData, dayName);
        
        // Render HTML
        const html = this.dailyTemplate(processedData);
        
        await page.setContent(html, { waitUntil: 'networkidle0' });
        
        // Generate PDF buffer
        const pdfBuffer = await page.pdf({
            format: 'Letter',
            landscape: false,
            margin: {
                top: '0.25in',
                right: '0.25in',
                bottom: '0.25in',
                left: '0.25in'
            },
            printBackground: true,
            preferCSSPageSize: true
        });
        
        await page.close();
        return pdfBuffer;
    }

    processWeeklyData(weekData) {
        const timeSlots = this.generateTimeSlots();
        const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        
        const processedTimeSlots = timeSlots.map(time => {
            const dayData = days.map(day => {
                const dayEvents = weekData.days[day] || [];
                const eventsAtTime = dayEvents.filter(event => 
                    this.isEventAtTime(event, time)
                );
                
                return {
                    day: day,
                    events: eventsAtTime.map(event => ({
                        ...event,
                        topOffset: this.calculateTopOffset(event, time),
                        height: this.calculateEventHeight(event),
                        source: this.getEventSourceClass(event.source),
                        sourceDisplay: event.source,
                        timeRange: `${event.startTime}-${event.endTime}`
                    }))
                };
            });
            
            return {
                time: time,
                days: dayData
            };
        });

        return {
            weekNumber: weekData.weekNumber,
            startDate: weekData.startDate,
            endDate: weekData.endDate,
            mondayDate: this.formatDate(weekData.dates.monday),
            tuesdayDate: this.formatDate(weekData.dates.tuesday),
            wednesdayDate: this.formatDate(weekData.dates.wednesday),
            thursdayDate: this.formatDate(weekData.dates.thursday),
            fridayDate: this.formatDate(weekData.dates.friday),
            saturdayDate: this.formatDate(weekData.dates.saturday),
            sundayDate: this.formatDate(weekData.dates.sunday),
            timeSlots: processedTimeSlots
        };
    }

    processDailyData(weekData, dayName) {
        const dayEvents = weekData.days[dayName] || [];
        const timeSlots = this.generateTimeSlots();
        
        // Calculate statistics
        const stats = this.calculateDayStatistics(dayEvents);
        
        // Process events with positioning and enhanced details
        const processedEvents = dayEvents.map(event => {
            // Check if event has notes or action items
            const hasDetails = !!(
                event.eventNotes || 
                event.actionItems || 
                event.notes || 
                event.actions
            );
            
            // Normalize notes and action items
            const eventNotes = event.eventNotes || event.notes;
            const actionItems = event.actionItems || event.actions;
            
            return {
                ...event,
                topPosition: this.calculateDailyTopPosition(event),
                height: this.calculateDailyEventHeight(event, hasDetails),
                source: this.getEventSourceClass(event.source),
                sourceDisplay: event.source,
                timeRange: `${event.startTime}-${event.endTime}`,
                dayNameLower: dayName,
                hasDetails: hasDetails,
                eventNotes: eventNotes,
                actionItems: actionItems
            };
        });

        // Navigation data
        const dayIndex = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].indexOf(dayName);
        const prevDay = dayIndex > 0 ? ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'][dayIndex - 1] : 'sunday';
        const nextDay = dayIndex < 6 ? ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'][dayIndex + 1] : 'monday';

        return {
            dayName: this.capitalizeFirst(dayName),
            dayNameLower: dayName,
            fullDate: this.formatFullDate(weekData.dates[dayName]),
            appointmentCount: stats.appointmentCount,
            scheduledHours: stats.scheduledHours,
            availableHours: stats.availableHours,
            freeTimePercent: stats.freeTimePercent,
            timeSlots: timeSlots.map(time => ({ time })),
            events: processedEvents,
            prevDay: prevDay,
            nextDay: nextDay,
            prevDayName: this.capitalizeFirst(prevDay),
            nextDayName: this.capitalizeFirst(nextDay)
        };
    }

    generateTimeSlots() {
        const slots = [];
        for (let hour = 6; hour < 24; hour++) {
            slots.push(`${hour.toString().padStart(2, '0')}:00`);
            slots.push(`${hour.toString().padStart(2, '0')}:30`);
        }
        return slots;
    }

    isEventAtTime(event, timeSlot) {
        const eventStart = this.timeToMinutes(event.startTime);
        const eventEnd = this.timeToMinutes(event.endTime);
        const slotTime = this.timeToMinutes(timeSlot);
        
        return slotTime >= eventStart && slotTime < eventEnd;
    }

    calculateTopOffset(event, currentTime) {
        const eventStart = this.timeToMinutes(event.startTime);
        const slotTime = this.timeToMinutes(currentTime);
        
        if (slotTime === eventStart) {
            return 0;
        }
        return 0; // Events start at the beginning of their time slot
    }

    calculateEventHeight(event) {
        const duration = this.timeToMinutes(event.endTime) - this.timeToMinutes(event.startTime);
        const slotsSpanned = duration / 30; // 30 minutes per slot
        return slotsSpanned * 20; // 20px per slot
    }

    calculateDailyTopPosition(event) {
        const startMinutes = this.timeToMinutes(event.startTime);
        const dayStartMinutes = this.timeToMinutes('06:00');
        const relativeMinutes = startMinutes - dayStartMinutes;
        return (relativeMinutes / 30) * 30; // 30px per 30-minute slot
    }

    calculateDailyEventHeight(event, hasDetails = false) {
        const duration = this.timeToMinutes(event.endTime) - this.timeToMinutes(event.startTime);
        const baseHeight = (duration / 30) * 30; // 30px per 30-minute slot
        
        if (hasDetails) {
            // Calculate additional height based on content
            const eventNotes = event.eventNotes || event.notes || [];
            const actionItems = event.actionItems || event.actions || [];
            
            const notesCount = Array.isArray(eventNotes) ? eventNotes.length : (eventNotes ? 1 : 0);
            const actionsCount = Array.isArray(actionItems) ? actionItems.length : (actionItems ? 1 : 0);
            
            // Add approximately 15px per note/action item, plus section headers
            let extraHeight = (notesCount + actionsCount) * 15;
            if (notesCount > 0) extraHeight += 20; // Section header
            if (actionsCount > 0) extraHeight += 20; // Section header
            
            return Math.max(baseHeight, baseHeight + extraHeight);
        }
        
        return baseHeight;
    }

    calculateDayStatistics(events) {
        const appointmentCount = events.length;
        const scheduledMinutes = events.reduce((total, event) => {
            return total + (this.timeToMinutes(event.endTime) - this.timeToMinutes(event.startTime));
        }, 0);
        
        const scheduledHours = Math.round((scheduledMinutes / 60) * 10) / 10;
        const totalDayMinutes = 18 * 60; // 6 AM to 12 AM
        const availableMinutes = totalDayMinutes - scheduledMinutes;
        const availableHours = Math.round((availableMinutes / 60) * 10) / 10;
        const freeTimePercent = Math.round((availableMinutes / totalDayMinutes) * 100);

        return {
            appointmentCount,
            scheduledHours,
            availableHours,
            freeTimePercent
        };
    }

    timeToMinutes(timeStr) {
        const [hours, minutes] = timeStr.split(':').map(Number);
        return hours * 60 + minutes;
    }

    getEventSourceClass(source) {
        const sourceMap = {
            'GOOGLE CALENDAR': 'google',
            'OUTLOOK': 'outlook',
            'APPLE CALENDAR': 'apple',
            'MANUAL': 'manual'
        };
        return sourceMap[source.toUpperCase()] || 'other';
    }

    formatDate(dateStr) {
        const date = new Date(dateStr);
        return `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
    }

    formatFullDate(dateStr) {
        const date = new Date(dateStr);
        const months = ['January', 'February', 'March', 'April', 'May', 'June',
                       'July', 'August', 'September', 'October', 'November', 'December'];
        return `${months[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;
    }

    capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    async combinePagesIntoPDF(pageBuffers, outputPath) {
        const PDFDocument = require('pdf-lib').PDFDocument;
        
        const mergedPdf = await PDFDocument.create();
        
        for (const buffer of pageBuffers) {
            const pdf = await PDFDocument.load(buffer);
            const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
            pages.forEach(page => mergedPdf.addPage(page));
        }
        
        // Add hyperlinks and bookmarks
        await this.addHyperlinks(mergedPdf);
        
        const pdfBytes = await mergedPdf.save();
        await fs.writeFile(outputPath, pdfBytes);
    }

    async addHyperlinks(pdfDoc) {
        // Add bookmarks for navigation
        const pages = pdfDoc.getPages();
        
        // Weekly overview bookmark
        if (pages[0]) {
            pdfDoc.addBookmark('Weekly Overview', pages[0]);
        }
        
        // Daily bookmarks
        const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        dayNames.forEach((dayName, index) => {
            if (pages[index + 1]) {
                pdfDoc.addBookmark(dayName, pages[index + 1]);
            }
        });
    }

    async close() {
        if (this.browser) {
            await this.browser.close();
        }
    }
}

module.exports = WeeklyPlannerPDFGenerator;

