const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;
const WeeklyPlannerPDFGenerator = require('./pdf_generator');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files
app.use('/static', express.static(path.join(__dirname, 'static')));

// Serve frontend at root
app.get('/test', (req, res) => {
    res.sendFile(path.join(__dirname, 'static', 'index.html'));
});

// Initialize PDF generator
const pdfGenerator = new WeeklyPlannerPDFGenerator();

// Routes
app.get('/', (req, res) => {
    res.json({
        message: 'Weekly Planner PDF Export API',
        version: '1.0.0',
        endpoints: {
            'POST /export-pdf': 'Export weekly planner as PDF',
            'GET /health': 'Health check',
            'GET /sample-data': 'Get sample data structure'
        }
    });
});

app.get('/health', (req, res) => {
    res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

app.get('/sample-data', (req, res) => {
    const sampleData = {
        weekNumber: 28,
        startDate: '2025-07-14',
        endDate: '2025-07-20',
        dates: {
            monday: '2025-07-14',
            tuesday: '2025-07-15',
            wednesday: '2025-07-16',
            thursday: '2025-07-17',
            friday: '2025-07-18',
            saturday: '2025-07-19',
            sunday: '2025-07-20'
        },
        days: {
            monday: [
                {
                    id: 'evt_001',
                    title: 'Angelica Ruden Appointment',
                    startTime: '07:00',
                    endTime: '08:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Morning appointment'
                },
                {
                    id: 'evt_002',
                    title: 'Dan re: Supervision',
                    startTime: '08:00',
                    endTime: '09:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Supervision meeting'
                },
                {
                    id: 'evt_003',
                    title: 'Sherrifa Hoosein Appointment',
                    startTime: '09:00',
                    endTime: '10:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_004',
                    title: 'Krista Flood Appointment',
                    startTime: '10:30',
                    endTime: '11:30',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_005',
                    title: 'Amberly Comeau Appointment',
                    startTime: '11:30',
                    endTime: '12:30',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_006',
                    title: 'Nancy Grossman Appointment',
                    startTime: '12:30',
                    endTime: '13:30',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_007',
                    title: 'Sarah Palladino Appointment',
                    startTime: '13:30',
                    endTime: '14:30',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_008',
                    title: 'Jason Laskin Appointment',
                    startTime: '15:00',
                    endTime: '16:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_009',
                    title: 'Noah Silverman Appointment',
                    startTime: '16:00',
                    endTime: '17:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_010',
                    title: 'Steven Deluca Appointment',
                    startTime: '17:00',
                    endTime: '18:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_011',
                    title: 'David Grossman Appointment',
                    startTime: '18:30',
                    endTime: '20:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Evening appointment'
                }
            ],
            tuesday: [
                {
                    id: 'evt_012',
                    title: 'Coffee with Nora',
                    startTime: '08:00',
                    endTime: '09:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Coffee meeting'
                },
                {
                    id: 'evt_013',
                    title: 'Call with Blake',
                    startTime: '10:00',
                    endTime: '11:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Phone call'
                },
                {
                    id: 'evt_014',
                    title: 'Healthfirst Orientation - Zoom',
                    startTime: '14:00',
                    endTime: '15:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Virtual orientation'
                },
                {
                    id: 'evt_015',
                    title: 'Vivian Meador',
                    startTime: '19:00',
                    endTime: '20:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Evening appointment'
                }
            ],
            wednesday: [
                {
                    id: 'evt_016',
                    title: 'Meera Zucker',
                    startTime: '10:00',
                    endTime: '11:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_017',
                    title: 'Valentina Gjidoda',
                    startTime: '11:00',
                    endTime: '12:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_018',
                    title: 'Paul Benjamin',
                    startTime: '13:00',
                    endTime: '14:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_019',
                    title: 'Gavin Perna',
                    startTime: '17:00',
                    endTime: '18:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_020',
                    title: 'Max Moskowitz',
                    startTime: '18:00',
                    endTime: '19:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_021',
                    title: 'Owen Lennon',
                    startTime: '19:00',
                    endTime: '20:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_022',
                    title: 'David Grossman',
                    startTime: '20:00',
                    endTime: '21:30',
                    source: 'GOOGLE CALENDAR',
                    description: 'Evening appointment'
                }
            ],
            thursday: [
                {
                    id: 'evt_023',
                    title: 'Ruben Spilberg',
                    startTime: '07:30',
                    endTime: '08:30',
                    source: 'GOOGLE CALENDAR',
                    description: 'Morning appointment'
                },
                {
                    id: 'evt_024',
                    title: 'Kristi Rook',
                    startTime: '09:30',
                    endTime: '10:30',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_025',
                    title: 'Ava Moskowitz',
                    startTime: '13:00',
                    endTime: '14:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_026',
                    title: 'Hector Mendez',
                    startTime: '15:00',
                    endTime: '16:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_027',
                    title: 'Freddy Rodriguez',
                    startTime: '16:00',
                    endTime: '17:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_028',
                    title: 'Nico Luppino',
                    startTime: '18:00',
                    endTime: '19:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                }
            ],
            friday: [
                {
                    id: 'evt_029',
                    title: 'Richie Hayes',
                    startTime: '07:00',
                    endTime: '08:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Morning appointment'
                },
                {
                    id: 'evt_030',
                    title: 'John Best',
                    startTime: '08:00',
                    endTime: '09:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_031',
                    title: 'Noah Silverman',
                    startTime: '13:00',
                    endTime: '14:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_032',
                    title: 'Sarah Palladino',
                    startTime: '15:00',
                    endTime: '16:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_033',
                    title: 'Trendall Storey',
                    startTime: '16:00',
                    endTime: '17:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                },
                {
                    id: 'evt_034',
                    title: 'Michael Bower & Bob Delmond',
                    startTime: '17:00',
                    endTime: '18:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Group appointment'
                },
                {
                    id: 'evt_035',
                    title: 'Brianna Brickman',
                    startTime: '18:00',
                    endTime: '19:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Client appointment'
                }
            ],
            saturday: [
                {
                    id: 'evt_036',
                    title: 'Calvin Hill',
                    startTime: '10:00',
                    endTime: '11:00',
                    source: 'GOOGLE CALENDAR',
                    description: 'Weekend appointment'
                }
            ],
            sunday: []
        }
    };
    
    res.json(sampleData);
});

app.post('/export-pdf', async (req, res) => {
    try {
        const weekData = req.body;
        
        // Validate required fields
        if (!weekData || !weekData.days) {
            return res.status(400).json({
                error: 'Invalid data format. Required: weekData with days object'
            });
        }
        
        // Generate unique filename
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `weekly-planner-${timestamp}.pdf`;
        const outputPath = path.join(__dirname, 'exports', filename);
        
        // Ensure exports directory exists
        await fs.mkdir(path.join(__dirname, 'exports'), { recursive: true });
        
        // Generate PDF
        console.log('Starting PDF generation...');
        await pdfGenerator.generatePDF(weekData, outputPath);
        console.log('PDF generation completed:', outputPath);
        
        // Send file
        res.download(outputPath, filename, (err) => {
            if (err) {
                console.error('Error sending file:', err);
                res.status(500).json({ error: 'Error sending PDF file' });
            } else {
                // Clean up file after sending (optional)
                setTimeout(() => {
                    fs.unlink(outputPath).catch(console.error);
                }, 60000); // Delete after 1 minute
            }
        });
        
    } catch (error) {
        console.error('PDF generation error:', error);
        res.status(500).json({
            error: 'PDF generation failed',
            details: error.message
        });
    }
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('Unhandled error:', error);
    res.status(500).json({
        error: 'Internal server error',
        details: error.message
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        error: 'Endpoint not found',
        availableEndpoints: [
            'GET /',
            'GET /health',
            'GET /sample-data',
            'POST /export-pdf'
        ]
    });
});

// Start server
app.listen(PORT, '0.0.0.0', async () => {
    console.log(`Weekly Planner PDF Export API running on port ${PORT}`);
    console.log(`Access the API at: http://localhost:${PORT}`);
    
    try {
        await pdfGenerator.initialize();
        console.log('PDF generator initialized successfully');
    } catch (error) {
        console.error('Failed to initialize PDF generator:', error);
    }
});

// Graceful shutdown
process.on('SIGTERM', async () => {
    console.log('Shutting down gracefully...');
    await pdfGenerator.close();
    process.exit(0);
});

process.on('SIGINT', async () => {
    console.log('Shutting down gracefully...');
    await pdfGenerator.close();
    process.exit(0);
});

module.exports = app;

