const WeeklyPlannerPDFGenerator = require('./pdf_generator_enhanced');
const fs = require('fs').promises;
const path = require('path');

async function testEnhancedPDFExport() {
    console.log('Starting Enhanced PDF export test with Event Notes and Action Items...');
    
    const generator = new WeeklyPlannerPDFGenerator();
    
    try {
        await generator.initialize();
        console.log('PDF generator initialized');
        
        // Load sample data with event notes
        const sampleDataPath = path.join(__dirname, 'sample_data_enhanced.json');
        const sampleDataRaw = await fs.readFile(sampleDataPath, 'utf8');
        const sampleData = JSON.parse(sampleDataRaw);
        
        console.log('Loaded enhanced sample data with event notes and action items');
        
        // Log events with details for verification
        Object.entries(sampleData.days).forEach(([day, events]) => {
            events.forEach(event => {
                if (event.eventNotes || event.actionItems) {
                    console.log(`${day}: ${event.title} has enhanced details`);
                    if (event.eventNotes) {
                        console.log(`  Notes: ${Array.isArray(event.eventNotes) ? event.eventNotes.length + ' items' : '1 item'}`);
                    }
                    if (event.actionItems) {
                        console.log(`  Actions: ${Array.isArray(event.actionItems) ? event.actionItems.length + ' items' : '1 item'}`);
                    }
                }
            });
        });
        
        const outputPath = path.join(__dirname, 'enhanced_weekly_planner.pdf');
        
        console.log('Generating enhanced PDF with event notes...');
        await generator.generatePDF(sampleData, outputPath);
        
        console.log(`Enhanced PDF generated successfully: ${outputPath}`);
        console.log('Features included:');
        console.log('✓ 8-page PDF structure (1 weekly + 7 daily)');
        console.log('✓ Bidirectional hyperlinks');
        console.log('✓ Event notes and action items');
        console.log('✓ Dynamic event height calculation');
        console.log('✓ Exact visual replication');
        console.log('Test completed successfully!');
        
    } catch (error) {
        console.error('Enhanced test failed:', error);
        console.error('Stack trace:', error.stack);
    } finally {
        await generator.close();
    }
}

// Test individual components
async function testComponentsIndividually() {
    console.log('\n--- Testing Individual Components ---');
    
    const generator = new WeeklyPlannerPDFGenerator();
    
    try {
        await generator.initialize();
        
        // Test time slot generation
        const timeSlots = generator.generateTimeSlots();
        console.log(`✓ Time slots generated: ${timeSlots.length} slots from ${timeSlots[0]} to ${timeSlots[timeSlots.length - 1]}`);
        
        // Test event height calculation with notes
        const testEvent = {
            startTime: '09:00',
            endTime: '10:00',
            eventNotes: ['Note 1', 'Note 2'],
            actionItems: ['Action 1', 'Action 2', 'Action 3']
        };
        
        const heightWithDetails = generator.calculateDailyEventHeight(testEvent, true);
        const heightWithoutDetails = generator.calculateDailyEventHeight(testEvent, false);
        
        console.log(`✓ Event height calculation:`);
        console.log(`  Without details: ${heightWithoutDetails}px`);
        console.log(`  With details: ${heightWithDetails}px`);
        console.log(`  Additional height for notes: ${heightWithDetails - heightWithoutDetails}px`);
        
        // Test data processing
        const sampleData = {
            days: {
                monday: [testEvent]
            },
            dates: {
                monday: '2025-07-14'
            }
        };
        
        const processedData = generator.processDailyData(sampleData, 'monday');
        console.log(`✓ Data processing: Event has details = ${processedData.events[0].hasDetails}`);
        
    } catch (error) {
        console.error('Component test failed:', error);
    } finally {
        await generator.close();
    }
}

// Run tests if this file is executed directly
if (require.main === module) {
    (async () => {
        await testEnhancedPDFExport();
        await testComponentsIndividually();
    })();
}

module.exports = { testEnhancedPDFExport, testComponentsIndividually };

