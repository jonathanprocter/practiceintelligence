# Weekly Planner PDF Export with Bidirectional Hyperlinks

A comprehensive solution for exporting weekly planner data as an 8-page PDF with bidirectional hyperlinks between weekly overview and daily views. This system replicates the exact visual appearance of your web application while adding sophisticated navigation capabilities.

## Features

- **Exact Visual Replication**: Maintains pixel-perfect consistency with your original web application
- **8-Page PDF Structure**: 1 weekly overview (landscape) + 7 daily views (portrait)
- **Bidirectional Hyperlinks**: Seamless navigation between weekly and daily views
- **Event Cross-Referencing**: Click events in weekly view to jump to daily view and vice versa
- **Proportional Event Blocks**: Event heights reflect actual duration
- **Multiple Calendar Sources**: Support for Google Calendar, Outlook, Apple Calendar, and manual entries
- **RESTful API**: Easy integration with existing applications
- **Replit Compatible**: Ready to deploy on Replit platform

## Quick Start

### 1. Installation

```bash
npm install
```

### 2. Start the Server

```bash
npm start
```

The API will be available at `http://localhost:3000`

### 3. Test PDF Export

```bash
npm test
```

This will generate a sample PDF using test data.

## API Endpoints

### GET /
Returns API information and available endpoints.

### GET /health
Health check endpoint.

### GET /sample-data
Returns sample data structure for testing.

### POST /export-pdf
Exports weekly planner data as PDF.

**Request Body:**
```json
{
  "weekNumber": 28,
  "startDate": "2025-07-14",
  "endDate": "2025-07-20",
  "dates": {
    "monday": "2025-07-14",
    "tuesday": "2025-07-15",
    "wednesday": "2025-07-16",
    "thursday": "2025-07-17",
    "friday": "2025-07-18",
    "saturday": "2025-07-19",
    "sunday": "2025-07-20"
  },
  "days": {
    "monday": [
      {
        "id": "evt_001",
        "title": "Angelica Ruden Appointment",
        "startTime": "07:00",
        "endTime": "08:00",
        "source": "GOOGLE CALENDAR",
        "description": "Morning appointment"
      }
    ],
    "tuesday": [],
    // ... other days
  }
}
```

**Response:**
PDF file download

## Data Structure

### Week Data Object

```javascript
{
  weekNumber: number,           // Week number (e.g., 28)
  startDate: string,           // ISO date string (e.g., "2025-07-14")
  endDate: string,             // ISO date string (e.g., "2025-07-20")
  dates: {
    monday: string,            // ISO date string
    tuesday: string,           // ISO date string
    wednesday: string,         // ISO date string
    thursday: string,          // ISO date string
    friday: string,            // ISO date string
    saturday: string,          // ISO date string
    sunday: string             // ISO date string
  },
  days: {
    monday: Event[],           // Array of events for Monday
    tuesday: Event[],          // Array of events for Tuesday
    // ... etc for all days
  }
}
```

### Event Object

```javascript
{
  id: string,                  // Unique event identifier
  title: string,               // Event title/name
  startTime: string,           // Start time in HH:MM format (24-hour)
  endTime: string,             // End time in HH:MM format (24-hour)
  source: string,              // Event source ("GOOGLE CALENDAR", "OUTLOOK", etc.)
  description?: string         // Optional event description
}
```

## PDF Structure

### Page 1: Weekly Overview (Landscape)
- Complete weekly grid showing all 7 days
- Time slots from 06:00 to 23:30 in 30-minute increments
- Events displayed as proportional blocks
- Hyperlinked day headers and events

### Pages 2-8: Daily Views (Portrait)
- One page per day (Monday through Sunday)
- Detailed timeline with proportional event blocks
- Statistics panel (appointments, scheduled time, availability)
- Navigation controls with hyperlinks

## Hyperlink System

### Navigation Types

1. **Day Navigation**: Click day headers in weekly view to jump to daily pages
2. **Event Cross-Reference**: Click events to navigate between weekly and daily views
3. **Return Navigation**: "Weekly Overview" button returns to main page
4. **Sequential Navigation**: Previous/next day arrows for daily browsing

### Link Destinations

- `#day_monday` - Monday daily page
- `#day_tuesday` - Tuesday daily page
- `#week_overview` - Weekly overview page
- `#week_event_[eventId]` - Specific event in weekly view
- `#day_[dayname]_event_[eventId]` - Specific event in daily view

## Customization

### Visual Styling

Modify `shared_styles.css` to customize:
- Color schemes for different event sources
- Typography and font sizes
- Spacing and layout dimensions
- Print-specific styling

### Templates

- `weekly_template.html` - Weekly overview layout
- `daily_template.html` - Daily view layout

Both templates use Handlebars for dynamic content injection.

### Event Colors

Default color scheme:
- **Google Calendar**: Blue (`#e3f2fd` background, `#1976d2` border)
- **Outlook**: Orange (`#fff3e0` background, `#f57c00` border)
- **Apple Calendar**: Pink (`#fce4ec` background, `#c2185b` border)
- **Manual**: Green (`#e8f5e8` background, `#388e3c` border)
- **Other**: Purple (`#f3e5f5` background, `#7b1fa2` border)

## Integration with Existing Applications

### Frontend Integration

```javascript
// Example: Export current week data
async function exportWeeklyPDF(weekData) {
  const response = await fetch('/export-pdf', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(weekData)
  });
  
  if (response.ok) {
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'weekly-planner.pdf';
    a.click();
  }
}
```

### Backend Integration

```javascript
const WeeklyPlannerPDFGenerator = require('./pdf_generator');

const generator = new WeeklyPlannerPDFGenerator();
await generator.initialize();

// Generate PDF
const outputPath = './output.pdf';
await generator.generatePDF(weekData, outputPath);

await generator.close();
```

## Deployment on Replit

1. **Import Project**: Upload all files to your Replit project
2. **Install Dependencies**: Run `npm install` in the shell
3. **Configure Environment**: Ensure Puppeteer dependencies are available
4. **Start Application**: Click the "Run" button or use `npm start`
5. **Test Export**: Use the `/sample-data` endpoint to get test data

### Replit-Specific Configuration

The project includes:
- `.replit` - Replit configuration
- `replit.nix` - System dependencies including Chromium for Puppeteer
- Environment variables for Puppeteer configuration

## Troubleshooting

### Common Issues

**Puppeteer Launch Errors**
- Ensure all system dependencies are installed
- Check that Chromium is available in the environment
- Verify `PUPPETEER_EXECUTABLE_PATH` environment variable

**PDF Generation Failures**
- Validate input data structure
- Check for missing required fields
- Ensure event times are in correct format (HH:MM)

**Hyperlink Issues**
- Verify anchor IDs match between templates
- Check that PDF viewer supports internal links
- Ensure proper HTML structure in templates

### Debug Mode

Enable debug logging:
```javascript
process.env.DEBUG = 'puppeteer:*';
```

## Performance Considerations

- **Memory Usage**: Each PDF generation creates browser instances
- **Concurrent Requests**: Limit simultaneous PDF generations
- **File Cleanup**: Generated PDFs are automatically cleaned up after download
- **Caching**: Consider caching frequently requested PDFs

## Browser Compatibility

Generated PDFs work with:
- Adobe Acrobat Reader
- Chrome/Chromium PDF viewer
- Firefox PDF viewer
- Safari PDF viewer
- Edge PDF viewer

## License

MIT License - Feel free to modify and distribute as needed.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review the API documentation
3. Test with sample data first
4. Verify data structure matches requirements

## Version History

- **v1.0.0**: Initial release with full hyperlink support
- Exact visual replication of web application
- 8-page PDF structure with bidirectional navigation
- RESTful API for easy integration
- Replit deployment compatibility

