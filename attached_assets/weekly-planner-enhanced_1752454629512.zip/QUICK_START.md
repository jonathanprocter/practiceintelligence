# Quick Start Guide - Weekly Planner PDF Export

## 🚀 Get Started in 5 Minutes

### Step 1: Upload to Replit
1. Go to [replit.com](https://replit.com)
2. Create new Node.js Repl
3. Upload the `weekly-planner-pdf-export.zip` file
4. Extract all files to your Repl

### Step 2: Run the Application
1. Click the "Run" button in Replit
2. Wait for dependencies to install
3. Server will start on port 3000

### Step 3: Test PDF Export
1. Open the web preview
2. Navigate to `/test`
3. Click "Load Sample Data"
4. Click "Generate PDF"
5. PDF downloads automatically!

## 📋 What You Get

✅ **8-Page PDF Structure**
- Page 1: Weekly overview (landscape)
- Pages 2-8: Daily views (portrait)

✅ **Bidirectional Hyperlinks**
- Click day headers to jump to daily pages
- Click events to cross-reference between views
- "Weekly Overview" button returns to main page

✅ **Exact Visual Replication**
- Matches your current browser views
- Proportional event block heights
- Consistent color schemes

✅ **RESTful API**
- `/export-pdf` endpoint for integration
- JSON data input
- PDF file output

## 🔧 Integration

### Frontend Integration
```javascript
// Export current week
async function exportPDF(weekData) {
  const response = await fetch('/export-pdf', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(weekData)
  });
  
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'weekly-planner.pdf';
  a.click();
}
```

### Data Format
```json
{
  "weekNumber": 28,
  "startDate": "2025-07-14",
  "endDate": "2025-07-20",
  "dates": {
    "monday": "2025-07-14",
    "tuesday": "2025-07-15"
  },
  "days": {
    "monday": [
      {
        "id": "evt_001",
        "title": "Meeting",
        "startTime": "09:00",
        "endTime": "10:00",
        "source": "GOOGLE CALENDAR"
      }
    ]
  }
}
```

## 📞 Support

- Check `README.md` for detailed documentation
- Review `IMPLEMENTATION_GUIDE.md` for advanced setup
- Test with sample data first
- Use `/health` endpoint to verify API status

## 🎯 Next Steps

1. **Customize Styling**: Edit `shared_styles.css`
2. **Modify Templates**: Update HTML templates
3. **Add Branding**: Include your logo and colors
4. **Deploy**: Use Replit's deployment features

Ready to export beautiful PDFs with hyperlinks! 🎉

