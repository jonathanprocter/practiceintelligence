# Weekly Planner PDF Export - Implementation Guide for Replit

This guide provides step-by-step instructions for implementing the Weekly Planner PDF Export system on Replit, ensuring exact visual replication of your current application with bidirectional hyperlinks.

## Overview

The system generates an 8-page PDF with:
- **Page 1**: Weekly overview (landscape orientation)
- **Pages 2-8**: Daily views (portrait orientation, Monday-Sunday)
- **Bidirectional hyperlinks** between all related elements
- **Exact visual replication** of your current browser views

## Step 1: Replit Setup

### 1.1 Create New Replit Project

1. Go to [replit.com](https://replit.com)
2. Click "Create Repl"
3. Select "Node.js" as the template
4. Name your project (e.g., "weekly-planner-pdf-export")

### 1.2 Upload Project Files

Upload all the following files to your Replit project:

**Core Application Files:**
- `app.js` - Main Express server
- `pdf_generator.js` - PDF generation engine
- `package.json` - Dependencies and scripts
- `test_export.js` - Testing utilities

**Template Files:**
- `weekly_template.html` - Weekly overview template
- `daily_template.html` - Daily view template
- `shared_styles.css` - Shared styling

**Configuration Files:**
- `.replit` - Replit configuration
- `replit.nix` - System dependencies
- `README.md` - Documentation
- `IMPLEMENTATION_GUIDE.md` - This guide

**Frontend Files:**
- `static/index.html` - Testing interface

## Step 2: Install Dependencies

### 2.1 Automatic Installation

Replit will automatically install dependencies when you run the project. If needed, manually run:

```bash
npm install
```

### 2.2 Verify Dependencies

The following packages will be installed:
- `express` - Web server framework
- `puppeteer` - PDF generation
- `handlebars` - Template engine
- `pdf-lib` - PDF manipulation
- `cors` - Cross-origin requests
- `moment` - Date handling

## Step 3: Configuration

### 3.1 Environment Variables

Replit automatically configures:
- `PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true`
- `PUPPETEER_EXECUTABLE_PATH` - Points to system Chromium
- `NODE_ENV=production`

### 3.2 System Dependencies

The `replit.nix` file includes all required system packages:
- Chromium browser
- Graphics libraries
- Font packages
- Audio libraries (for headless browser)

## Step 4: Testing the Implementation

### 4.1 Start the Server

1. Click the "Run" button in Replit
2. The server will start on port 3000
3. You'll see: "Weekly Planner PDF Export API running on port 3000"

### 4.2 Test API Health

1. Open the web preview
2. Navigate to `/health` endpoint
3. Should return: `{"status":"healthy","timestamp":"..."}`

### 4.3 Test PDF Generation

**Option A: Using the Web Interface**
1. Navigate to `/test` in the web preview
2. Click "Load Sample Data"
3. Click "Generate PDF"
4. PDF should download automatically

**Option B: Using the Command Line**
```bash
npm test
```

**Option C: Using API Directly**
```bash
curl -X POST http://localhost:3000/export-pdf \
  -H "Content-Type: application/json" \
  -d @sample_data.json \
  --output weekly-planner.pdf
```

## Step 5: Integration with Your Application

### 5.1 Data Format Preparation

Transform your existing event data to match the required format:

```javascript
const weekData = {
  weekNumber: 28,
  startDate: "2025-07-14",
  endDate: "2025-07-20",
  dates: {
    monday: "2025-07-14",
    tuesday: "2025-07-15",
    // ... etc
  },
  days: {
    monday: [
      {
        id: "unique_event_id",
        title: "Event Title",
        startTime: "09:00",
        endTime: "10:00",
        source: "GOOGLE CALENDAR",
        description: "Optional description"
      }
    ],
    // ... other days
  }
};
```

### 5.2 Frontend Integration

Add export functionality to your existing application:

```javascript
async function exportWeeklyPDF(weekData) {
  try {
    const response = await fetch('/export-pdf', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(weekData)
    });
    
    if (response.ok) {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `weekly-planner-${weekData.startDate}.pdf`;
      a.click();
      window.URL.revokeObjectURL(url);
    } else {
      throw new Error('PDF generation failed');
    }
  } catch (error) {
    console.error('Export error:', error);
    alert('Failed to export PDF: ' + error.message);
  }
}
```

### 5.3 Backend Integration

If you have an existing backend, integrate the PDF generator:

```javascript
const WeeklyPlannerPDFGenerator = require('./pdf_generator');

// Initialize once
const pdfGenerator = new WeeklyPlannerPDFGenerator();
await pdfGenerator.initialize();

// Use in your routes
app.post('/export-weekly-pdf', async (req, res) => {
  try {
    const weekData = req.body;
    const outputPath = `./exports/weekly-${Date.now()}.pdf`;
    
    await pdfGenerator.generatePDF(weekData, outputPath);
    
    res.download(outputPath, 'weekly-planner.pdf');
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

## Step 6: Customization

### 6.1 Visual Styling

Modify `shared_styles.css` to match your brand:

```css
/* Update color scheme */
.event-google {
  background: #your-color;
  border-color: #your-border-color;
}

/* Update fonts */
body {
  font-family: 'Your-Font', sans-serif;
}

/* Update spacing */
.event-block {
  padding: 6px 10px; /* Adjust as needed */
}
```

### 6.2 Template Modifications

Update templates to match your exact layout:

**Weekly Template (`weekly_template.html`):**
- Modify grid structure
- Adjust time slots
- Update header information

**Daily Template (`daily_template.html`):**
- Modify statistics panel
- Adjust timeline layout
- Update navigation elements

### 6.3 Event Source Mapping

Update event source colors in `pdf_generator.js`:

```javascript
getEventSourceClass(source) {
  const sourceMap = {
    'YOUR_CALENDAR_SOURCE': 'custom-color-class',
    'GOOGLE CALENDAR': 'google',
    'OUTLOOK': 'outlook',
    // Add your sources
  };
  return sourceMap[source.toUpperCase()] || 'other';
}
```

## Step 7: Production Deployment

### 7.1 Replit Deployment

1. Ensure your Repl is running correctly
2. Click "Deploy" in Replit
3. Choose deployment type (Autoscale recommended)
4. Configure custom domain if needed

### 7.2 Performance Optimization

**Memory Management:**
```javascript
// Limit concurrent PDF generations
const semaphore = new Semaphore(2); // Max 2 concurrent

app.post('/export-pdf', async (req, res) => {
  await semaphore.acquire();
  try {
    // PDF generation code
  } finally {
    semaphore.release();
  }
});
```

**Caching:**
```javascript
// Cache frequently requested PDFs
const cache = new Map();
const cacheKey = JSON.stringify(weekData);

if (cache.has(cacheKey)) {
  return cache.get(cacheKey);
}
```

### 7.3 Error Handling

Implement comprehensive error handling:

```javascript
app.use((error, req, res, next) => {
  console.error('PDF Generation Error:', {
    message: error.message,
    stack: error.stack,
    timestamp: new Date().toISOString(),
    requestData: req.body
  });
  
  res.status(500).json({
    error: 'PDF generation failed',
    details: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
  });
});
```

## Step 8: Troubleshooting

### 8.1 Common Issues

**Puppeteer Launch Failures:**
```bash
# Check if Chromium is available
which chromium

# Verify environment variables
echo $PUPPETEER_EXECUTABLE_PATH
```

**PDF Generation Timeouts:**
- Increase timeout in Puppeteer configuration
- Reduce concurrent requests
- Check memory usage

**Hyperlink Issues:**
- Verify anchor IDs in templates
- Test with different PDF viewers
- Check HTML structure

### 8.2 Debug Mode

Enable detailed logging:

```javascript
// In pdf_generator.js
const browser = await puppeteer.launch({
  headless: true,
  args: [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-dev-shm-usage', // Add for memory issues
    '--disable-gpu' // Add for graphics issues
  ],
  dumpio: true // Enable console output
});
```

### 8.3 Memory Issues

If experiencing memory problems:

```javascript
// Add memory management
process.on('warning', (warning) => {
  console.warn('Memory Warning:', warning);
});

// Monitor memory usage
setInterval(() => {
  const usage = process.memoryUsage();
  console.log('Memory Usage:', {
    rss: Math.round(usage.rss / 1024 / 1024) + 'MB',
    heapUsed: Math.round(usage.heapUsed / 1024 / 1024) + 'MB'
  });
}, 30000);
```

## Step 9: Maintenance

### 9.1 Regular Updates

- Update dependencies monthly: `npm update`
- Monitor Puppeteer compatibility with Chromium
- Test PDF generation after updates

### 9.2 Monitoring

Implement health checks:

```javascript
app.get('/health/detailed', async (req, res) => {
  try {
    // Test PDF generation with minimal data
    const testData = { /* minimal test data */ };
    await pdfGenerator.generatePDF(testData, '/tmp/health-test.pdf');
    
    res.json({
      status: 'healthy',
      pdfGeneration: 'working',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      status: 'unhealthy',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});
```

### 9.3 Backup and Recovery

- Regularly backup your Replit project
- Keep template files in version control
- Document any customizations made

## Step 10: Advanced Features

### 10.1 Batch Processing

For multiple weeks:

```javascript
app.post('/export-multiple-weeks', async (req, res) => {
  const { weeks } = req.body;
  const zipPath = './exports/multiple-weeks.zip';
  
  // Generate PDFs for each week
  // Combine into ZIP file
  // Send ZIP download
});
```

### 10.2 Custom Branding

Add your logo and branding:

```html
<!-- In templates -->
<div class="header">
  <img src="{{logoUrl}}" alt="Logo" class="logo">
  <h1>{{companyName}} Weekly Planner</h1>
</div>
```

### 10.3 Email Integration

Send PDFs via email:

```javascript
const nodemailer = require('nodemailer');

app.post('/email-pdf', async (req, res) => {
  const { weekData, emailAddress } = req.body;
  
  // Generate PDF
  const pdfPath = await generatePDF(weekData);
  
  // Send email with PDF attachment
  await sendEmail(emailAddress, pdfPath);
});
```

## Conclusion

This implementation provides a complete solution for exporting your weekly planner as a professional PDF with bidirectional hyperlinks. The system maintains exact visual consistency with your current application while adding sophisticated navigation capabilities.

For support or questions, refer to the README.md file or test with the provided sample data to ensure everything is working correctly.

